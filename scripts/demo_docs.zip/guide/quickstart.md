# Quickstart

Demo library 1.0 quickstart guide.
Install with pip and call demo.run() to start.
