# API Reference

demo.run(host, port) starts the server.
demo.stop() shuts it down gracefully.
